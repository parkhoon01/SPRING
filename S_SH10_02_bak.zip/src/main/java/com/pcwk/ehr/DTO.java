package com.pcwk.ehr;

public class DTO {

}
