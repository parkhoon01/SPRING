'use strict';

let isEmpty = function(value){
  if(null ==value || value == "" || "null" == value || value == undefined){
    return true;
  }else{
    return false;
  }
  
};
 